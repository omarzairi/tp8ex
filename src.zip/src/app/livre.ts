export class Livre {
    constructor(  
        public id:number,      
        public titre:string,
        public prix:number,
        public nouveau:boolean){
    }
}
